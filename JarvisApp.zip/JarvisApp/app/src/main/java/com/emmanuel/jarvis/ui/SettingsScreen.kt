package com.emmanuel.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.emmanuel.jarvis.util.Prefs

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var serverUrl by remember { mutableStateOf(Prefs.getServerUrl(context)) }
    var wakeWordEnabled by remember { mutableStateOf(Prefs.isWakeWordEnabled(context)) }
    var confirmationEnabled by remember { mutableStateOf(Prefs.isActionConfirmationEnabled(context)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(24.dp)
    ) {
        Text("Paramètres JARVIS", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = serverUrl,
            onValueChange = {
                serverUrl = it
                Prefs.setServerUrl(context, it)
            },
            label = { Text("URL du serveur proxy (ex: https://ton-serveur.com)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mot d'activation (\"Hey JARVIS\") — Phase 3", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = wakeWordEnabled, onCheckedChange = {
                wakeWordEnabled = it
                Prefs.setWakeWordEnabled(context, it)
            })
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Confirmer avant les actions sensibles", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = confirmationEnabled, onCheckedChange = {
                confirmationEnabled = it
                Prefs.setActionConfirmationEnabled(context, it)
            })
        }

        Spacer(Modifier.height(32.dp))
        TextButton(onClick = onBack) { Text("Retour") }
    }
}
