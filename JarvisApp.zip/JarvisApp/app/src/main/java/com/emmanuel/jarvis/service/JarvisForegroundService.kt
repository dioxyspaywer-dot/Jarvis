package com.emmanuel.jarvis.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * PHASE 3 (pas encore branché à l'UI).
 * Permet à JARVIS de rester actif quand l'utilisateur a quitté l'app,
 * pour le mot d'activation ("Hey JARVIS") et le mode assistant actif.
 *
 * À faire pour compléter cette phase :
 *  - intégrer un moteur de mot d'activation hors-ligne (ex : Porcupine, Vosk)
 *  - démarrer ce service depuis MainScreen quand l'utilisateur active le mode assistant
 */
class JarvisForegroundService : Service() {

    private val channelId = "jarvis_assistant_channel"

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Assistant JARVIS", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS")
            .setContentText("Mode assistant actif")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
