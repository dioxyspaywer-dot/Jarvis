package com.emmanuel.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * PHASE 2 (pas encore branché à l'UI).
 * Une fois activé par l'utilisateur dans Paramètres > Accessibilité,
 * ce service permet de :
 *  - lire le contenu affiché à l'écran (describeScreen)
 *  - simuler un appui sur un texte/bouton visible (tapOnText)
 *  - faire défiler l'écran (scrollDown)
 *
 * Rappel important : ce type de service est très surveillé par Google Play.
 * Pour un usage strictement personnel (APK installé manuellement), pas de restriction.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // À implémenter Phase 2 : capturer le contexte de l'écran en continu si besoin
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /** Résume ce qui est visible à l'écran, en texte, pour l'envoyer à Gemini comme contexte. */
    fun describeScreen(): String {
        val root = rootInActiveWindow ?: return "Aucun contenu accessible."
        val builder = StringBuilder()
        collectText(root, builder)
        return builder.toString().ifBlank { "Écran sans texte détecté." }
    }

    private fun collectText(node: AccessibilityNodeInfo, builder: StringBuilder) {
        node.text?.let { if (it.isNotBlank()) builder.append(it).append(" | ") }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, builder) }
        }
    }

    /** Cherche un noeud dont le texte contient targetText et clique dessus. */
    fun tapOnText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, targetText) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(target, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByText(child, target)?.let { return it }
        }
        return null
    }

    fun scrollDown(): Boolean {
        val root = rootInActiveWindow ?: return false
        return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }
}
