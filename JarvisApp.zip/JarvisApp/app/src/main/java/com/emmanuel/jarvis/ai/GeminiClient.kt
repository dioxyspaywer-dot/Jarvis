package com.emmanuel.jarvis.ai

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * IMPORTANT : ce client ne parle JAMAIS directement à l'API Gemini.
 * Il parle à TON serveur (voir /server/index.js), qui seul détient la clé API.
 * C'est ce serveur qui appelle Gemini et renvoie un plan d'action structuré.
 */
class GeminiClient(private val serverUrl: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun requestPlan(
        userUtterance: String,
        conversationHistory: List<Pair<String, String>>, // (role, texte)
        screenContext: String? = null,
        onSuccess: (JarvisPlan) -> Unit,
        onError: (String) -> Unit
    ) {
        if (serverUrl.isBlank()) {
            onError("Aucune URL de serveur configurée. Va dans Paramètres.")
            return
        }

        val body = JSONObject().apply {
            put("utterance", userUtterance)
            put("screenContext", screenContext ?: JSONObject.NULL)
            val historyArray = JSONArray()
            conversationHistory.forEach { (role, text) ->
                historyArray.put(JSONObject().put("role", role).put("text", text))
            }
            put("history", historyArray)
        }

        val request = Request.Builder()
            .url("$serverUrl/plan")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onError("Impossible de joindre le serveur : ${e.message}")
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    val raw = it.body?.string()
                    if (!it.isSuccessful || raw == null) {
                        onError("Erreur serveur (${it.code})")
                        return
                    }
                    try {
                        onSuccess(parsePlan(raw))
                    } catch (e: Exception) {
                        onError("Réponse du serveur illisible : ${e.message}")
                    }
                }
            }
        })
    }

    private fun parsePlan(raw: String): JarvisPlan {
        val json = JSONObject(raw)
        val spokenReply = json.optString("spokenReply", "")
        val actionsJson = json.optJSONArray("actions") ?: JSONArray()
        val actions = mutableListOf<JarvisAction>()
        for (i in 0 until actionsJson.length()) {
            val a = actionsJson.getJSONObject(i)
            actions.add(
                JarvisAction(
                    type = a.optString("type", "UNKNOWN"),
                    target = a.optString("target", null),
                    value = a.optString("value", null),
                    requiresConfirmation = a.optBoolean("requiresConfirmation", false)
                )
            )
        }
        return JarvisPlan(spokenReply, actions)
    }
}
