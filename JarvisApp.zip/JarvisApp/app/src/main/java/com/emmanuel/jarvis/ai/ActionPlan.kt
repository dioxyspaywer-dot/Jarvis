package com.emmanuel.jarvis.ai

/**
 * Une action unique que JARVIS peut exécuter.
 * "type" correspond à ActionExecutor : OPEN_APP, OPEN_SETTINGS_WIFI, OPEN_SETTINGS_BLUETOOTH,
 * SEARCH_YOUTUBE, SPEAK, GO_BACK, GO_HOME, SCROLL_DOWN, TAP_TEXT, TYPE_TEXT, UNKNOWN.
 */
data class JarvisAction(
    val type: String,
    val target: String? = null,      // ex : nom de l'app, texte à chercher, texte du bouton
    val value: String? = null,       // ex : texte à écrire
    val requiresConfirmation: Boolean = false
)

/**
 * Réponse complète attendue du serveur (qui l'a lui-même obtenue de Gemini) :
 * un message à dire à l'utilisateur + une liste d'actions à exécuter dans l'ordre.
 */
data class JarvisPlan(
    val spokenReply: String,
    val actions: List<JarvisAction>
)
