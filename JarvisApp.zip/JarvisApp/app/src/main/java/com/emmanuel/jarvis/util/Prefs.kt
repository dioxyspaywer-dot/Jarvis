package com.emmanuel.jarvis.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stockage local chiffré. On ne stocke JAMAIS la clé Gemini ici :
 * seulement l'URL de TON serveur proxy (voir /server), qui lui détient la clé.
 */
object Prefs {
    private const val FILE_NAME = "jarvis_secure_prefs"
    private const val KEY_SERVER_URL = "server_url"
    private const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
    private const val KEY_ACTION_CONFIRMATION = "action_confirmation_enabled"

    private fun prefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getServerUrl(context: Context): String =
        prefs(context).getString(KEY_SERVER_URL, "") ?: ""

    fun setServerUrl(context: Context, url: String) {
        prefs(context).edit().putString(KEY_SERVER_URL, url).apply()
    }

    fun isWakeWordEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_WAKE_WORD_ENABLED, false)

    fun setWakeWordEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_WAKE_WORD_ENABLED, enabled).apply()
    }

    fun isActionConfirmationEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ACTION_CONFIRMATION, true)

    fun setActionConfirmationEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ACTION_CONFIRMATION, enabled).apply()
    }
}
