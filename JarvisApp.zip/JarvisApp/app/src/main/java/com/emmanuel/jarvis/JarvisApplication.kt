package com.emmanuel.jarvis

import android.app.Application

class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Point d'extension future : initialisation de librairies (wake-word, logs, etc.)
    }
}
