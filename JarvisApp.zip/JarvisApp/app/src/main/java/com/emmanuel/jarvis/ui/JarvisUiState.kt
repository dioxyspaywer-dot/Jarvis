package com.emmanuel.jarvis.ui

enum class JarvisStatus {
    READY, LISTENING, THINKING, ACTING, DONE, ERROR
}

data class ConversationTurn(
    val role: String, // "user" ou "jarvis"
    val text: String
)

data class JarvisUiState(
    val status: JarvisStatus = JarvisStatus.READY,
    val statusMessage: String = "",
    val conversation: List<ConversationTurn> = emptyList(),
    val pendingConfirmationText: String? = null
)
