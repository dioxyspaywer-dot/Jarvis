package com.emmanuel.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.emmanuel.jarvis.ai.JarvisAction

/**
 * Exécute les actions du plan renvoyé par Gemini.
 * Phase 1 : tout ce qui passe par des Intents Android classiques (pas besoin d'accessibilité).
 * Phase 2 branchera TAP_TEXT / SCROLL_DOWN / TYPE_TEXT sur JarvisAccessibilityService.
 */
class ActionExecutor(private val context: Context) {

    fun execute(action: JarvisAction): Boolean {
        return when (action.type) {
            "OPEN_APP" -> openApp(action.target)
            "OPEN_SETTINGS_WIFI" -> startSettings(Settings.ACTION_WIFI_SETTINGS)
            "OPEN_SETTINGS_BLUETOOTH" -> startSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
            "SEARCH_YOUTUBE" -> searchYouTube(action.target)
            "OPEN_BROWSER_SEARCH" -> openBrowserSearch(action.target)
            "GO_HOME" -> goHome()
            "SPEAK" -> true // la parole est gérée par TextToSpeechManager côté ViewModel
            "TAP_TEXT", "SCROLL_DOWN", "TYPE_TEXT", "GO_BACK" -> {
                // Nécessite le service d'accessibilité actif (Phase 2)
                false
            }
            else -> false
        }
    }

    private fun openApp(appNameOrPackage: String?): Boolean {
        if (appNameOrPackage.isNullOrBlank()) return false
        val pm = context.packageManager

        // 1. Essai direct comme nom de package
        pm.getLaunchIntentForPackage(appNameOrPackage)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(it)
            return true
        }

        // 2. Recherche approximative parmi les apps installées par nom affiché
        val installed = pm.getInstalledApplications(0)
        val match = installed.firstOrNull {
            pm.getApplicationLabel(it).toString()
                .contains(appNameOrPackage, ignoreCase = true)
        }
        val launchIntent = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else false
    }

    private fun startSettings(action: String): Boolean {
        return try {
            val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun searchYouTube(query: String?): Boolean {
        if (query.isNullOrBlank()) return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(
            "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        )).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    private fun openBrowserSearch(query: String?): Boolean {
        if (query.isNullOrBlank()) return false
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun goHome(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }
}
