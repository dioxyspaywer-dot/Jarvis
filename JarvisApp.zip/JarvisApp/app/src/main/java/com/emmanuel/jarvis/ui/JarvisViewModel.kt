package com.emmanuel.jarvis.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.emmanuel.jarvis.actions.ActionExecutor
import com.emmanuel.jarvis.ai.GeminiClient
import com.emmanuel.jarvis.ai.JarvisAction
import com.emmanuel.jarvis.ai.JarvisPlan
import com.emmanuel.jarvis.util.Prefs
import com.emmanuel.jarvis.voice.SpeechToTextManager
import com.emmanuel.jarvis.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(
        JarvisUiState(status = JarvisStatus.READY, statusMessage = "Je suis prêt.")
    )
    val uiState: StateFlow<JarvisUiState> = _uiState

    private val tts = TextToSpeechManager(application)
    private val actionExecutor = ActionExecutor(application)
    private var speechToText: SpeechToTextManager? = null

    // File d'actions en attente d'une confirmation utilisateur
    private var pendingActions: List<JarvisAction> = emptyList()

    fun onMicPressed() {
        val context = getApplication<Application>()
        speechToText = SpeechToTextManager(
            context = context,
            onListeningStarted = {
                _uiState.update { it.copy(status = JarvisStatus.LISTENING, statusMessage = "En écoute…") }
            },
            onResult = { text -> handleUserUtterance(text) },
            onError = { message ->
                _uiState.update { it.copy(status = JarvisStatus.ERROR, statusMessage = message) }
            }
        )
        speechToText?.startListening()
    }

    private fun handleUserUtterance(text: String) {
        _uiState.update {
            it.copy(
                status = JarvisStatus.THINKING,
                statusMessage = "Analyse de la commande…",
                conversation = it.conversation + ConversationTurn("user", text)
            )
        }

        val serverUrl = Prefs.getServerUrl(getApplication())
        val client = GeminiClient(serverUrl)
        val history = _uiState.value.conversation.map { it.role to it.text }

        client.requestPlan(
            userUtterance = text,
            conversationHistory = history,
            onSuccess = { plan -> onPlanReceived(plan) },
            onError = { message ->
                _uiState.update { it.copy(status = JarvisStatus.ERROR, statusMessage = message) }
                tts.speak("Désolé, une erreur est survenue.")
            }
        )
    }

    private fun onPlanReceived(plan: JarvisPlan) {
        _uiState.update {
            it.copy(
                status = JarvisStatus.ACTING,
                statusMessage = "Action en cours…",
                conversation = it.conversation + ConversationTurn("jarvis", plan.spokenReply)
            )
        }
        tts.speak(plan.spokenReply)

        val (needsConfirmation, safeActions) = plan.actions.partition { it.requiresConfirmation }

        safeActions.forEach { actionExecutor.execute(it) }

        if (needsConfirmation.isNotEmpty()) {
            pendingActions = needsConfirmation
            _uiState.update {
                it.copy(pendingConfirmationText = "Confirmer : ${needsConfirmation.first().type} ?")
            }
        } else {
            finishTurn()
        }
    }

    fun confirmPendingActions() {
        pendingActions.forEach { actionExecutor.execute(it) }
        pendingActions = emptyList()
        _uiState.update { it.copy(pendingConfirmationText = null) }
        finishTurn()
    }

    fun cancelPendingActions() {
        pendingActions = emptyList()
        _uiState.update { it.copy(pendingConfirmationText = null) }
        tts.speak("D'accord, j'annule.")
        finishTurn()
    }

    private fun finishTurn() {
        _uiState.update { it.copy(status = JarvisStatus.DONE, statusMessage = "Terminé.") }
    }

    override fun onCleared() {
        super.onCleared()
        tts.destroy()
        speechToText?.destroy()
    }
}
