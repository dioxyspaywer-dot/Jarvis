package com.emmanuel.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun colorForStatus(status: JarvisStatus): Color = when (status) {
    JarvisStatus.READY -> Color(0xFF2196F3)
    JarvisStatus.LISTENING -> Color(0xFF00E5FF)
    JarvisStatus.THINKING -> Color(0xFFFFC107)
    JarvisStatus.ACTING -> Color(0xFF9C27B0)
    JarvisStatus.DONE -> Color(0xFF4CAF50)
    JarvisStatus.ERROR -> Color(0xFFF44336)
}

@Composable
fun MainScreen(viewModel: JarvisViewModel, onOpenSettings: () -> Unit) {
    val state by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        IconlessSettingsButton(onOpenSettings)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "JARVIS",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 32.dp)
            )

            Spacer(Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Bottom
            ) {
                items(state.conversation) { turn ->
                    Text(
                        text = (if (turn.role == "user") "Toi : " else "JARVIS : ") + turn.text,
                        color = if (turn.role == "user") Color(0xFFB0BEC5) else Color.White,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(state.statusMessage, color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(120.dp)
                    .background(colorForStatus(state.status), CircleShape)
                    .align(Alignment.CenterHorizontally)
            )

            Spacer(Modifier.height(32.dp))

            Button(
                onClick = { viewModel.onMicPressed() },
                modifier = Modifier.size(72.dp),
                shape = CircleShape
            ) {
                Text("🎤")
            }

            state.pendingConfirmationText?.let { confirmText ->
                Spacer(Modifier.height(16.dp))
                Text(confirmText, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(onClick = { viewModel.confirmPendingActions() }) { Text("Oui") }
                    OutlinedButton(onClick = { viewModel.cancelPendingActions() }) { Text("Non") }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun IconlessSettingsButton(onOpenSettings: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
        TextButton(onClick = onOpenSettings, modifier = Modifier.padding(8.dp)) {
            Text("Paramètres", color = Color.Gray)
        }
    }
}
